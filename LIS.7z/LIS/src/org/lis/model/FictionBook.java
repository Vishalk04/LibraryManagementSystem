/*package org.lis.model;

public class FictionBook extends Book{
	
	public FictionBook(){}

	public FictionBook(String bookId, String title, String auther) {
		super(bookId, title, auther);
		// TODO Auto-generated constructor stub
	}

}
*/
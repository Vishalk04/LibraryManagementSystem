/*package org.lis.model;

public class ActionBook extends Book {

	public ActionBook(String bookId, String title, String auther) {
		super(bookId, title, auther);
		// TODO Auto-generated constructor stub
	}

	public ActionBook() {
		// TODO Auto-generated constructor stub
	}

}
*/
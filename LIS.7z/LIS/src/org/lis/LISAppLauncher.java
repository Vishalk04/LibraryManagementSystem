package org.lis;

public class LISAppLauncher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LISApp.run();
	}

}
